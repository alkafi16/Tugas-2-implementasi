<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include "Layout/header.html" ?>

    <main>
        <p>Halo selamat datang di Website kami</p>
    </main>

    <?php include "Layout/footer.html" ?>
    
</body>
</html>